from django.apps import AppConfig


class DjangoSiteTagConfig(AppConfig):
    name = 'django_site_tag'
